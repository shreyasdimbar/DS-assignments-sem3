#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int data) {
        this->data = data;
        this->next = NULL;
        this->prev = NULL;
    }
};

class DoublyLinkedList {
public:
    Node* head;

    DoublyLinkedList() {
        head = NULL;
    }

    void insertAtEnd(int data) {
        Node* newNode = new Node(data);
        if (head == NULL) {
            head = newNode;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }

    void concatenate(DoublyLinkedList &list2) {
        if (head == NULL) {
            head = list2.head;
            list2.head = NULL;
            cout << "Lists concatenated." << endl;
            return;
        }
        if (list2.head == NULL) {
            cout << "Lists concatenated." << endl;
            return;
        }

        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }

        temp->next = list2.head;
        list2.head->prev = temp;
        list2.head = NULL;
        
        cout << "Lists concatenated." << endl;
    }

    void display() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }
        Node* temp = head;
        cout << "List: NULL <-> ";
        while (temp != NULL) {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    DoublyLinkedList list1;
    list1.insertAtEnd(10);
    list1.insertAtEnd(20);
    list1.insertAtEnd(30);

    DoublyLinkedList list2;
    list2.insertAtEnd(40);
    list2.insertAtEnd(50);

    cout << "First List:" << endl;
    list1.display();

    cout << "Second List:" << endl;
    list2.display();

    list1.concatenate(list2);

    cout << "Concatenated List:" << endl;
    list1.display();

    return 0;
}
