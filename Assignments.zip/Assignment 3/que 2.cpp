#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};

class CircularLinkedList {
public:
    Node* head;

    CircularLinkedList() {
        head = NULL;
    }

    void push(int data) {
        Node* newNode = new Node(data);
        if (head == NULL) {
            head = newNode;
            newNode->next = head;
            return;
        }

        Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }

        temp->next = newNode;
        newNode->next = head;
    }

    void display() {
        if (head == NULL) {
            cout << "The list is currently empty." << endl;
            return;
        }

        Node* temp = head;
        cout << "Here's your circular list: ";
        do {
            cout << temp->data << " -> ";
            temp = temp->next;
        } while (temp != head);
        cout << "(head: " << head->data << ")" << endl;
    }

    void deleteEvenNodes() {
        if (head == NULL || head->next == head) {
            cout << "List is too short, no even positions to delete." << endl;
            return;
        }

        Node* prev = head;
        Node* current = head->next;

        while (true) {
            prev->next = current->next;

            cout << "Deleting node with value: " << current->data << endl;
            delete current;

            if (prev->next == head) {
                break;
            }

            prev = prev->next;

            if (prev->next == head) {
                break;
            }
            
            current = prev->next;
        }
    }
};

int main() {
    CircularLinkedList cll;

    cll.push(1);
    cll.push(2);
    cll.push(3);
    cll.push(4);
    cll.push(5);
    cll.push(6);
    cll.push(7);

    cout << "--- Original List ---" << endl;
    cll.display();

    cout << "\n--- Deleting Even Position Nodes ---" << endl;
    cll.deleteEvenNodes();

    cout << "\n--- List After Deletion ---" << endl;
    cll.display();

    return 0;
}
