#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};

class CircularLinkedList {
public:
    Node* head;

    CircularLinkedList() {
        head = NULL;
    }

    void sortedInsert(int data) {
        Node* newNode = new Node(data);
        if (head == NULL) {
            head = newNode;
            newNode->next = head;
            return;
        }

        if (head->data >= newNode->data) {
            Node* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != head && temp->next->data < newNode->data) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    void display() {
        if (head == NULL) {
            cout << "List is empty." << endl;
            return;
        }
        Node* temp = head;
        cout << "List: ";
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
        cout << endl;
    }
};

Node* sortedMerge(Node* a, Node* b) {
    if (a == NULL) return b;
    if (b == NULL) return a;

    Node* result = NULL;
    if (a->data <= b->data) {
        result = a;
        result->next = sortedMerge(a->next, b);
    } else {
        result = b;
        result->next = sortedMerge(a, b->next);
    }
    return result;
}

void mergeLists(CircularLinkedList &list1, CircularLinkedList &list2) {
    if (list1.head == NULL) {
        list1.head = list2.head;
        list2.head = NULL;
        return;
    }
    if (list2.head == NULL) {
        return;
    }

    Node* head1 = list1.head;
    Node* head2 = list2.head;

    Node* last1 = head1;
    while (last1->next != head1) {
        last1 = last1->next;
    }

    Node* last2 = head2;
    while (last2->next != head2) {
        last2 = last2->next;
    }

    last1->next = NULL;
    last2->next = NULL;

    list1.head = sortedMerge(head1, head2);
    list2.head = NULL;

    Node* new_last = list1.head;
    while (new_last->next != NULL) {
        new_last = new_last->next;
    }
    new_last->next = list1.head;
}

int main() {
    CircularLinkedList list1;
    list1.sortedInsert(2);
    list1.sortedInsert(5);
    list1.sortedInsert(8);

    CircularLinkedList list2;
    list2.sortedInsert(1);
    list2.sortedInsert(6);
    list2.sortedInsert(9);

    cout << "First List:" << endl;
    list1.display();

    cout << "Second List:" << endl;
    list2.display();

    mergeLists(list1, list2);

    cout << "Merged List:" << endl;
    list1.display();

    return 0;
}