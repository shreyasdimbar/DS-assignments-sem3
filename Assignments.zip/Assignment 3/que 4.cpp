#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int data) {
        this->data = data;
        this->next = NULL;
    }
};

class LinkedList {
public:
    Node* head;

    LinkedList() {
        head = NULL;
    }

    void push(int data) {
        Node* newNode = new Node(data);
        newNode->next = head;
        head = newNode;
    }

    bool search(int key) {
        return recursiveSearch(head, key);
    }

private:
    bool recursiveSearch(Node* current, int key) {
        if (current == NULL) {
            return false;
        }
        if (current->data == key) {
            return true;
        }
        return recursiveSearch(current->next, key);
    }
};

int main() {
    LinkedList list;
    list.push(10);
    list.push(20);
    list.push(30);
    list.push(40);
    list.push(50);

    int keyToFind1 = 30;
    if (list.search(keyToFind1)) {
        cout << keyToFind1 << " found." << endl;
    } else {
        cout << keyToFind1 << " not found." << endl;
    }

    int keyToFind2 = 99;
    if (list.search(keyToFind2)) {
        cout << keyToFind2 << " found." << endl;
    } else {
        cout << keyToFind2 << " not found." << endl;
    }

    return 0;
}