#include <iostream>
using namespace std;

class Node {
public:
    int val;
    Node *next;

    Node(int val) {
        this->val = val;
        this->next = NULL;
    }
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() {
        head = NULL;
    }

    void insertAtBeginning(int val) {
        Node* newNode = new Node(val);
        newNode->next = head;
        head = newNode;
        cout << "Okay, " << val << " is now at the front of the list." << endl;
    }

    void insertAtEnd(int val) {
        Node* newNode = new Node(val);
        if (head == NULL) {
            head = newNode;
            cout << "Got it, " << val << " has been added to the end." << endl;
            return;
        }
        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
        cout << "Got it, " << val << " has been added to the end." << endl;
    }

    void insertAtMiddle(int val, int pos) {
        if (pos <= 1) {
            insertAtBeginning(val);
            return;
        }
        Node* newNode = new Node(val);
        Node* temp = head;
        for (int i = 1; i < pos - 1 && temp != NULL; i++) {
            temp = temp->next;
        }
        if (temp == NULL) {
            cout << "That position doesn't exist, so I'll add it to the end for you." << endl;
            insertAtEnd(val);
        } else {
            newNode->next = temp->next;
            temp->next = newNode;
            cout << "Done! " << val << " is now at position " << pos << "." << endl;
        }
    }

    void deleteFromBeginning() {
        if (head == NULL) {
            cout << "Whoops, the list is empty! Nothing to delete." << endl;
            return;
        }
        Node* temp = head;
        head = head->next;
        cout << temp->val << " has been removed from the front." << endl;
        delete temp;
    }

    void deleteFromEnd() {
        if (head == NULL) {
            cout << "Whoops, the list is empty! Nothing to delete." << endl;
            return;
        }
        if (head->next == NULL) {
            cout << head->val << " has been removed from the end." << endl;
            delete head;
            head = NULL;
            return;
        }
        Node* temp = head;
        while (temp->next->next != NULL) {
            temp = temp->next;
        }
        Node* nodeToDelete = temp->next;
        cout << nodeToDelete->val << " has been removed from the end." << endl;
        temp->next = NULL;
        delete nodeToDelete;
    }

    void deleteFromMiddle(int pos) {
        if (head == NULL) {
            cout << "Whoops, the list is empty! Nothing to delete." << endl;
            return;
        }
        if (pos <= 1) {
            deleteFromBeginning();
            return;
        }
        Node* temp = head;
        for (int i = 1; i < pos - 1 && temp != NULL; i++) {
            temp = temp->next;
        }
        if (temp == NULL || temp->next == NULL) {
            cout << "Sorry, that position isn't valid. Can't delete." << endl;
            return;
        }
        Node* nodeToDelete = temp->next;
        temp->next = nodeToDelete->next;
        cout << "Removed " << nodeToDelete->val << " from position " << pos << "." << endl;
        delete nodeToDelete;
    }

    void display() {
        if (head == NULL) {
            cout << "The list is currently empty." << endl;
            return;
        }
        cout << "Here's your list: ";
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->val << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
};

int main() {
    LinkedList list;
    int choice, value, position;

    while (true) {
        cout << "\n--- Linked List Menu ---" << endl;
        cout << "1. Add to Beginning" << endl;
        cout << "2. Add to End" << endl;
        cout << "3. Add at a Specific Spot" << endl;
        cout << "4. Remove from Beginning" << endl;
        cout << "5. Remove from End" << endl;
        cout << "6. Remove from a Specific Spot" << endl;
        cout << "7. Show the List" << endl;
        cout << "8. Exit" << endl;
        cout << "--------------------------" << endl;
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter a number to add: ";
                cin >> value;
                list.insertAtBeginning(value);
                break;
            case 2:
                cout << "Enter a number to add: ";
                cin >> value;
                list.insertAtEnd(value);
                break;
            case 3:
                cout << "Enter a number to add: ";
                cin >> value;
                cout << "What position should it be in? ";
                cin >> position;
                list.insertAtMiddle(value, position);
                break;
            case 4:
                list.deleteFromBeginning();
                break;
            case 5:
                list.deleteFromEnd();
                break;
            case 6:
                cout << "Enter position to remove: ";
                cin >> position;
                list.deleteFromMiddle(position);
                break;
            case 7:
                list.display();
                break;
            case 8:
                cout << " shutting down" << endl;
                return 0;
            default:
                cout << " that's not a valid option. " << endl;
        }
    }

    return 0;
}
