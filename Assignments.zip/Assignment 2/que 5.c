#include <stdio.h>
void printBinary(int N) {
    if (N > 0) {
        printBinary(N / 2);         
        printf("%d", N % 2);        
    }
}
int main() {
    int N;
    printf("Enter an integer: ");
    scanf("%d", &N);
    if (N == 0) {
        printf("Binary: 0\n");
    } 
    else {
        printf("Binary: ");
        printBinary(N);
        printf("\n");
    }
    return 0;
}
