#include <stdio.h>
#include <stdlib.h>
int main() {
    
    int *N = (int *)malloc(sizeof(int));
    char *C = (char *)malloc(sizeof(char));
    float *F = (float *)malloc(sizeof(float));

    printf("Enter integer n : ");
    scanf("%d", N);

    printf("Enter character c : ");
    scanf(" %c", C);  // space before %c to consume any leftover newline

    printf("Enter float number : ");
    scanf("%f", F);

    printf("Integer : %d\n", *N);
    printf("Character : %c\n", *C);
    printf("Float : %.2f\n", *F);

    free(N);
    free(C);
    free(F);

    return 0;
}
