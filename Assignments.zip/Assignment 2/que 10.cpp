#include<iostream>
#include<cstdlib>
using namespace std;
 int main(int argc, char *argv[])
{
  int sum=0;
  for(int j=1;j<argc;j++){
    sum+=atoi(argv[j]);    
  }
  cout<<"Sum Of Command Line Arguments Is : "<<sum<<endl;
  return 0;
}
