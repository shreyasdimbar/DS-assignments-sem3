#include <iostream>
using namespace std;
void printOdd(int n);  
void printEven(int n) {
    if (n == 0)
        return;
    if (n % 2 == 0)
        cout << n << " ";
    printOdd(n - 1);
}
void printOdd(int n) {
    if (n == 0)
        return;
    if (n % 2 != 0)
        cout << n << " ";
    printEven(n - 1);
}
int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;
    if(n%2 == 0)
        printEven(n);
    else
        printOdd(n);  
    cout << endl;
    return 0;
}
