#include <iostream>
#include <string>
#include <fstream>
using namespace std;
int main(){
    ifstream file1("file1.txt");
    ifstream file2("file2.txt");
    ofstream merge("merge.txt");
    bool check = true;
    string s1;
    string s2;
    while(check){
        check = false;

        if(getline(file1,s1)){
            merge << s1 << endl;
            check = true ;
        }
        if(getline(file2,s2)){
            merge << s2 << endl;
            check = true ;
        }
    }
    file1.close();
    file2.close();
    merge.close();
    cout << "files merged into merge.txt" << endl;
    return 0;
}
