#include <iostream>
#include <string>
#include <fstream>
#include <map>
using namespace std;
int main(){
    ifstream file("words.txt");
    string word;
    map<string,int>occ;
    while( file >> word ){
        occ[word]++;
    }
    file.close();
    cout << "word occurances:"<<endl;
    for( const auto &val : occ ){
        cout << val.first << " : " << val.second << endl ;
    }
    return 0;
}
