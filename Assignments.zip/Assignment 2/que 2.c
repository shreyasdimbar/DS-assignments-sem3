#include <stdio.h>
#include <stdlib.h>
int main() {
    int N, max;
    printf("Enter number of elements (N): ");
    scanf("%d", &N);
    int *A = (int *)calloc(N, sizeof(int));
    printf("Enter %d elements:\n", N);
    for (int i = 0; i < N; i++) {
        scanf("%d", &A[i]);
    }
    max = A[0];
    for (int i = 1; i < N; i++) {
        if (A[i] > max) {
            max = A[i];
        }
    }
    printf("Largest element is: %d\n", max);
    free(A);
    return 0;
}
