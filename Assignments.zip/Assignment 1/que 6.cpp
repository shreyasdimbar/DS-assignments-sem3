#include <iostream>

using namespace std;
class Time {
    public: int hours;
    int minutes;
    int seconds;

    void read() {
        cin >> hours >> minutes >> seconds;
    }
};

void diff(Time t1,Time t2){
    int total1 = t1.hours * 3600 + t1.minutes * 60 + t1.seconds;
    int total2 = t2.hours * 3600 + t2.minutes * 60 + t2.seconds;
    int diff = abs(total2 - total1);
    int hrs = diff / 3600;
    diff %= 3600;
    int mnts = diff / 60;
    diff %= 60;
    int scnds = diff % 60;
    cout << hrs << ":" << mnts << ":" << scnds<< endl;
}

int main() {
    
    Time t1,t2;
    t1.read();
    t2.read();
    diff(t1,t2);
    

}
