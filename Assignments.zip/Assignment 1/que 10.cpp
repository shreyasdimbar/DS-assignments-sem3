#include <iostream>
using namespace std;

int main() {
    int n, day, fine = 0;
    cin >> n;

    int cars[1000];
    for(int i = 0; i < n; i++) {
        cin >> cars[i];
    }

    cin >> day;

    for(int i = 0; i < n; i++) {
        if ((day % 2 == 0 && cars[i] % 2 != 0) || (day % 2 != 0 && cars[i] % 2 == 0)) {
            fine += 250;
        }
    }

    cout << fine << endl;

    return 0;
}




