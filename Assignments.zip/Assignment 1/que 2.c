#include <stdio.h>

int main() {
    int n, count = 0;
    scanf("%d", &n);
    int arr[n];
    for(int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
for(int i = 0; i < n; i++) {
        int isUnique = 1;
        for(int j = 0; j < n; j++) {
            if(i != j && arr[i] == arr[j]) {
                isUnique = 0;
                break;
 }
        }
        if(isUnique)
            count++;
    }
printf("%d", count);
    return 0;
}
