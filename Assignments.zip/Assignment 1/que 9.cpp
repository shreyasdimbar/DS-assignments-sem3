#include <iostream>
using namespace std;

struct Measurement {
    int inches;
    float feet;
};

Measurement add(Measurement a, Measurement b) {
    Measurement result;
    result.inches = a.inches + b.inches;
    result.feet = a.feet + b.feet;
    return result;
}

int main() {
    Measurement m1, m2;
    cin >> m1.inches >> m1.feet;
    cin >> m2.inches >> m2.feet;

    Measurement total = add(m1, m2);

    cout << total.inches << " " << total.feet << endl;

    return 0;
}
