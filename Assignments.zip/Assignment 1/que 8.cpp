#include <iostream>
using namespace std;

struct Item {
    string name;
    float price;
    int quantity;

    float total() {
        return price * quantity;
    }
};

int main() {
    int C, N;
    cin >> C >> N;

    Item items[100];
    float totalExpense = 0;

    for(int i = 0; i < N; i++) {
        cin >> items[i].name >> items[i].price >> items[i].quantity;
        totalExpense += items[i].total();
    }

    float perPerson = totalExpense / C;

    cout << totalExpense << endl;
    cout << perPerson << endl;

    for(int i = 0; i < N; i++) {
        cout << items[i].name << " " << items[i].total() << endl;
    }

    return 0;
}
