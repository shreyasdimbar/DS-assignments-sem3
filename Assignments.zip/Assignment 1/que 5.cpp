#include <iostream>
#include <string>
#include <algorithm>  // for std::swap
using namespace std;

struct student {
    string name;
    int id;
};

void sortStudents(student arr[], int n) {
    for(int i = 0; i < n - 1; i++) {
        for(int j = i + 1; j < n; j++) {
            if(arr[i].id > arr[j].id) {
                swap(arr[i], arr[j]);
            }
        }
    }
}

student* solution(int N) {
    static student arr[100];
    for(int i = 0; i < N; i++) {
        cin >> arr[i].name >> arr[i].id;
    }
    sortStudents(arr, N);
    return arr;
}

int main() {
    int n;
    cin >> n;
    student* s = solution(n);
    for(int i = 0; i < n; i++) {
        cout << s[i].name << " " << s[i].id << "\n";
    }
    return 0;
}
