#include <iostream>
using namespace std;

struct Product {
    string name;
    float price;
    int quantity;

    float totalCost() {
        return price * quantity;
    }

    void read() {
        cin >> name >> price >> quantity;
    }

    void print() {
        cout << name << "\n";
        cout << price << "\n";
        cout << quantity << "\n";
        cout << totalCost() << "\n";
    }
};

int main() {
    Product p;
    p.read();
    p.print();
    return 0;
}
